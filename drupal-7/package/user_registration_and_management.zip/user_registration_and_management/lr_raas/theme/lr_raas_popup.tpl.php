<?php

/**
 * @file
 * Social Login User registration popup.
*/
?>
<div id="social-registration-form" class="LoginRadius_overlay LoginRadius_content_IE" style="display: none;">
  <div class="popupmain">
    <div class="lr-popupheading"> <?php print variable_get('lr_social_login_emailrequired_popup_top'); ?></div>
    <div class="raas-lr-form popupinner" id="social-registration-container">
      <div class="lr-noerror">
      </div>
    </div>
    <div class="lr-popup-footer">
    </div>
  </div>
</div>


